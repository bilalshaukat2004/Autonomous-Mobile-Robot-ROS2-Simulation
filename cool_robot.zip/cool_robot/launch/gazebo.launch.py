import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
import xacro


def generate_launch_description():

    pkg_name  = 'cool_robot'
    pkg_share = get_package_share_directory(pkg_name)

    # ── 1. Process xacro → URDF string ──────────────────────────────────────
    xacro_file = os.path.join(pkg_share, 'urdf', 'cool_robot.urdf.xacro')
    robot_description_raw = xacro.process_file(xacro_file).toxml()

    # ── 2. World file ────────────────────────────────────────────────────────
    world_file = os.path.join(pkg_share, 'worlds', 'cool_world.world')

    # ── 3. Launch Gazebo Harmonic ────────────────────────────────────────────
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory('ros_gz_sim'),
                         'launch', 'gz_sim.launch.py')
        ]),
        launch_arguments={
            'gz_args': f'-r {world_file}',
            'on_exit_shutdown': 'true'
        }.items()
    )

    # ── 4. Robot State Publisher ─────────────────────────────────────────────
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description_raw,
            'use_sim_time': True
        }]
    )

    # ── 5. Spawn robot ───────────────────────────────────────────────────────
    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-name',  'cool_robot',
            '-topic', 'robot_description',
            '-x', '0.0',
            '-y', '0.0',
            '-z', '0.05',
        ],
        output='screen'
    )

    # ── 6. ROS-GZ Bridges ────────────────────────────────────────────────────
    # Bridge Gazebo topics → ROS2
    # cmd_vel:  ROS2 → Gz  (we send commands to robot)
    # odom:     Gz → ROS2  (robot publishes odometry)
    # scan:     Gz → ROS2  (lidar data)
    # clock:    Gz → ROS2  (simulation time)
    # tf:       Gz → ROS2  (transforms from diff drive)
    # joint_states: Gz → ROS2 (wheel joint states)
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='gz_ros_bridge',
        arguments=[
            # cmd_vel: ROS2 → Gz
            '/cmd_vel@geometry_msgs/msg/Twist]gz.msgs.Twist',
            # odom: Gz → ROS2
            '/odom@nav_msgs/msg/Odometry[gz.msgs.Odometry',
            # scan: Gz → ROS2
            '/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan',
            # clock: Gz → ROS2
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
            # tf: Gz → ROS2
            '/tf@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V',
            # joint states: Gz → ROS2
            '/joint_states@sensor_msgs/msg/JointState[gz.msgs.Model',
        ],
        parameters=[{'use_sim_time': True}],
        output='screen'
    )

    return LaunchDescription([
        gazebo,
        robot_state_publisher,
        spawn_entity,
        bridge,
    ])
