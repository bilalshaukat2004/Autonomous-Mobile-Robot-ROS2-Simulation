#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
import xacro


def generate_launch_description():

    pkg_name  = 'cool_robot'
    pkg_share = get_package_share_directory(pkg_name)

    # ── Launch arguments ────────────────────────────────────────────────────
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    # ── 1. Process XACRO → URDF ─────────────────────────────────────────────
    xacro_file = os.path.join(pkg_share, 'urdf', 'cool_robot.urdf.xacro')
    robot_description_raw = xacro.process_file(xacro_file).toxml()

    # ── 2. World file ────────────────────────────────────────────────────────
    world_file = os.path.join(pkg_share, 'worlds', 'cool_world.world')

    # ── 3. Gazebo Harmonic ───────────────────────────────────────────────────
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory('ros_gz_sim'),
                         'launch', 'gz_sim.launch.py')
        ]),
        launch_arguments={
            'gz_args': f'-r {world_file}',
            'on_exit_shutdown': 'true'
        }.items()
    )

    # ── 4. Robot State Publisher ─────────────────────────────────────────────
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description_raw,
            'use_sim_time': True
        }]
    )

    # ── 5. Spawn robot in Gazebo ─────────────────────────────────────────────
    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-name',  'cool_robot',
            '-topic', 'robot_description',
            '-x', '0.0',
            '-y', '0.0',
            '-z', '0.05',
        ],
        output='screen'
    )

    # ── 6. ROS-GZ Bridges ────────────────────────────────────────────────────
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='gz_ros_bridge',
        arguments=[
            '/cmd_vel@geometry_msgs/msg/Twist]gz.msgs.Twist',
            '/odom@nav_msgs/msg/Odometry[gz.msgs.Odometry',
            '/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan',
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
            '/model/cool_robot/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry',
            '/joint_states@sensor_msgs/msg/JointState[gz.msgs.Model',
            '/tf@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V',
        ],
        parameters=[{'use_sim_time': True}],
        output='screen'
    )

    # ── 7. slam_toolbox (online async) ──────────────────────────────────────
    slam_params = os.path.join(pkg_share, 'config', 'slam_toolbox_params.yaml')

    slam_toolbox = IncludeLaunchDescription(
    PythonLaunchDescriptionSource([
        os.path.join(get_package_share_directory('slam_toolbox'),
                     'launch', 'online_async_launch.py')
    ]),
    launch_arguments={
        'slam_params_file': os.path.join(pkg_share, 'config', 'slam_toolbox_params.yaml'),
        'use_sim_time': 'true'
    }.items()
)

    # ── 8. RViz2 (SLAM view) ────────────────────────────────────────────────
    rviz_config = os.path.join(pkg_share, 'config', 'slam_rviz.rviz')
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config] if os.path.exists(rviz_config) else [],
        parameters=[{'use_sim_time': True}]
    )

    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='Use simulation (Gazebo) clock'
        ),
        gazebo,
        robot_state_publisher,
        spawn_entity,
        bridge,
        slam_toolbox,
        rviz,
    ])